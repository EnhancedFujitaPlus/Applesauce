/**
 * APPLESAUCE Gear & Inventory Module
 * Equipment system with dynamic inventory, stat bonuses, and loot drops
 */

class ApplesauceGear {
    constructor(engine) {
        this.engine = engine;
        
        // Equipment slots
        this.equipped = {
            helmet: null,
            torso: null,
            legs: null,
            shoes: null,
            board: null
        };
        
        // Storage inventory (items not equipped)
        this.inventory = [];
        
        // Cached stats (recalculated when gear changes)
        this.totalStats = this.getEmptyStats();
        
        // Inventory capacity (calculated from equipped gear)
        this.maxInventorySlots = 10; // Base capacity
        
        console.log('🎽 Gear module loaded');
    }
    
    // ===================================
    // STAT DEFINITIONS
    // ===================================
    
    // Get empty stat object
    getEmptyStats() {
        return {
            // Movement
            speedBonus: 0,          // Multiplier for max speed
            accelerationBonus: 0,   // Multiplier for acceleration
            turnBonus: 0,           // Multiplier for turn speed
            
            // Tricks
            jumpBonus: 0,           // Multiplier for jump height
            trickScoreBonus: 0,     // Multiplier for trick points
            comboMultiplier: 0,     // Additive combo bonus
            
            // Gore (your signature feature!)
            bloodAmount: 0,         // Multiplier for gore particle count
            splatRadius: 0,         // Multiplier for splatter size
            
            // Special
            grindSpeed: 0,          // Speed multiplier while grinding
            airControl: 0,          // Air movement control bonus
            kickflipSpeed: 0        // Kickflip rotation speed bonus
        };
    }
    
    // ===================================
    // GEAR ITEM STRUCTURE
    // ===================================
    
    /**
     * Gear Item Format:
     * {
     *   id: 'unique_item_id',
     *   name: 'Bloodstained Helmet',
     *   type: 'helmet', // helmet, torso, legs, shoes, board
     *   rarity: 'legendary', // common, uncommon, rare, epic, legendary
     *   
     *   // Visual data (from editor)
     *   customization: {
     *     colors: { shell: '#FF0000', visor: '#000000', accent: '#FFD700' },
     *     material: 'chrome',
     *     decal: { image: null, scale: 1, rotation: 0, opacity: 100 },
     *     elements: ['spikes', 'flames'],
     *     elementScale: 1.2
     *   },
     *   
     *   // Gameplay stats
     *   stats: {
     *     speedBonus: 0.15,
     *     bloodAmount: 2.5,
     *     trickScoreBonus: 0.3
     *   },
     *   
     *   // Loot properties
     *   dropChance: 0.05, // 5% drop rate
     *   level: 10 // Item level/tier
     * }
     */
    
    // ===================================
    // RARITY SYSTEM
    // ===================================
    
    getRarityData(rarity) {
        const rarities = {
            common: {
                color: 0x9e9e9e,
                colorHex: '#9e9e9e',
                inventorySlots: 1,
                statMultiplier: 1.0,
                dropChance: 0.50
            },
            uncommon: {
                color: 0x4ade80,
                colorHex: '#4ade80',
                inventorySlots: 2,
                statMultiplier: 1.3,
                dropChance: 0.30
            },
            rare: {
                color: 0x60a5fa,
                colorHex: '#60a5fa',
                inventorySlots: 4,
                statMultiplier: 1.6,
                dropChance: 0.15
            },
            epic: {
                color: 0xc084fc,
                colorHex: '#c084fc',
                inventorySlots: 7,
                statMultiplier: 2.0,
                dropChance: 0.04
            },
            legendary: {
                color: 0xfbbf24,
                colorHex: '#fbbf24',
                inventorySlots: 10,
                statMultiplier: 2.5,
                dropChance: 0.01
            }
        };
        
        return rarities[rarity] || rarities.common;
    }
    
    // ===================================
    // EQUIP/UNEQUIP SYSTEM
    // ===================================
    
    equipItem(item) {
        const slot = item.type;
        
        if (!this.equipped.hasOwnProperty(slot)) {
            console.error(`Invalid equipment slot: ${slot}`);
            return false;
        }
        
        // Unequip current item in that slot
        if (this.equipped[slot]) {
            this.unequipItem(slot);
        }
        
        // Equip new item
        this.equipped[slot] = item;
        
        // Recalculate stats and inventory
        this.recalculateStats();
        this.recalculateInventoryCapacity();
        
        // Apply visual changes (load 3D model)
        this.applyVisualGear(item);
        
        console.log(`✅ Equipped ${item.name}`);
        
        return true;
    }
    
    unequipItem(slot) {
        const item = this.equipped[slot];
        
        if (!item) {
            console.log(`No item equipped in ${slot}`);
            return null;
        }
        
        // Check if inventory has space
        if (this.inventory.length >= this.maxInventorySlots) {
            console.warn('Inventory full! Cannot unequip item.');
            return null;
        }
        
        // Move to inventory
        this.inventory.push(item);
        this.equipped[slot] = null;
        
        // Recalculate stats and inventory
        this.recalculateStats();
        this.recalculateInventoryCapacity();
        
        // Remove visual
        this.removeVisualGear(slot);
        
        console.log(`➖ Unequipped ${item.name}`);
        
        return item;
    }
    
    // ===================================
    // STAT CALCULATION
    // ===================================
    
    recalculateStats() {
        // Reset stats
        this.totalStats = this.getEmptyStats();
        
        // Sum all equipped item stats
        for (let slot in this.equipped) {
            const item = this.equipped[slot];
            if (item && item.stats) {
                for (let stat in item.stats) {
                    if (this.totalStats.hasOwnProperty(stat)) {
                        this.totalStats[stat] += item.stats[stat];
                    }
                }
            }
        }
        
        // Apply stats to engine
        this.applyStatsToEngine();
        
        console.log('📊 Stats recalculated:', this.totalStats);
    }
    
    applyStatsToEngine() {
        // Apply stat bonuses to engine state
        const state = this.engine.state;
        const baseConfig = this.engine.config;
        
        // Speed modifications
        state.maxSpeed = baseConfig.maxSpeed * (1 + this.totalStats.speedBonus);
        state.acceleration = baseConfig.acceleration * (1 + this.totalStats.accelerationBonus);
        state.turnSpeed = baseConfig.turnSpeed * (1 + this.totalStats.turnBonus);
        
        // Store bonuses for use in gameplay calculations
        state.gearStats = {
            jumpBonus: this.totalStats.jumpBonus,
            trickScoreBonus: this.totalStats.trickScoreBonus,
            comboMultiplier: this.totalStats.comboMultiplier,
            bloodAmount: this.totalStats.bloodAmount,
            splatRadius: this.totalStats.splatRadius,
            grindSpeed: this.totalStats.grindSpeed,
            airControl: this.totalStats.airControl,
            kickflipSpeed: this.totalStats.kickflipSpeed
        };
        
        console.log('⚙️ Gear stats applied to engine');
    }
    
    // ===================================
    // INVENTORY MANAGEMENT
    // ===================================
    
    recalculateInventoryCapacity() {
        // Base capacity
        let totalSlots = 10;
        
        // Add slots from equipped gear
        for (let slot in this.equipped) {
            const item = this.equipped[slot];
            if (item) {
                const rarityData = this.getRarityData(item.rarity);
                totalSlots += rarityData.inventorySlots;
            }
        }
        
        this.maxInventorySlots = totalSlots;
        
        console.log(`🎒 Inventory capacity: ${this.inventory.length}/${this.maxInventorySlots}`);
        
        return totalSlots;
    }
    
    addToInventory(item) {
        if (this.inventory.length >= this.maxInventorySlots) {
            console.warn('Inventory full!');
            return false;
        }
        
        this.inventory.push(item);
        console.log(`➕ Added ${item.name} to inventory`);
        
        return true;
    }
    
    removeFromInventory(itemId) {
        const index = this.inventory.findIndex(item => item.id === itemId);
        
        if (index === -1) {
            console.error(`Item ${itemId} not found in inventory`);
            return null;
        }
        
        const item = this.inventory.splice(index, 1)[0];
        console.log(`➖ Removed ${item.name} from inventory`);
        
        return item;
    }
    
    // ===================================
    // LOOT GENERATION
    // ===================================
    
    generateRandomLoot(enemyLevel = 1, forceRarity = null) {
        // Determine rarity
        let rarity = forceRarity || this.rollRarity();
        const rarityData = this.getRarityData(rarity);
        
        // Random gear type
        const types = ['helmet', 'torso', 'legs', 'shoes', 'board'];
        const type = types[Math.floor(Math.random() * types.length)];
        
        // Generate random stats based on rarity
        const stats = this.generateRandomStats(rarity, type);
        
        // Create item
        const item = {
            id: `${type}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
            name: this.generateItemName(type, rarity),
            type: type,
            rarity: rarity,
            stats: stats,
            customization: this.generateRandomCustomization(type, rarity),
            dropChance: rarityData.dropChance,
            level: enemyLevel
        };
        
        return item;
    }
    
    rollRarity() {
        const roll = Math.random();
        
        if (roll < 0.01) return 'legendary';      // 1%
        if (roll < 0.05) return 'epic';           // 4%
        if (roll < 0.20) return 'rare';           // 15%
        if (roll < 0.50) return 'uncommon';       // 30%
        return 'common';                          // 50%
    }
    
    generateRandomStats(rarity, type) {
        const rarityData = this.getRarityData(rarity);
        const multiplier = rarityData.statMultiplier;
        
        const stats = {};
        
        // Type-specific stat tendencies
        const typeStats = {
            helmet: ['trickScoreBonus', 'comboMultiplier', 'bloodAmount'],
            torso: ['speedBonus', 'accelerationBonus', 'grindSpeed'],
            legs: ['jumpBonus', 'kickflipSpeed', 'airControl'],
            shoes: ['turnBonus', 'airControl', 'trickScoreBonus'],
            board: ['speedBonus', 'jumpBonus', 'grindSpeed']
        };
        
        // Give 2-4 random stats from type pool
        const statPool = typeStats[type] || [];
        const numStats = 2 + Math.floor(Math.random() * 3); // 2-4 stats
        
        for (let i = 0; i < numStats; i++) {
            const statName = statPool[Math.floor(Math.random() * statPool.length)];
            
            if (!stats[statName]) {
                // Base value * rarity multiplier * random variance
                const baseValue = 0.1 + Math.random() * 0.2; // 0.1 to 0.3
                stats[statName] = parseFloat((baseValue * multiplier).toFixed(2));
            }
        }
        
        return stats;
    }
    
    generateItemName(type, rarity) {
        const prefixes = {
            common: ['Worn', 'Old', 'Basic', 'Simple'],
            uncommon: ['Sturdy', 'Reinforced', 'Quality', 'Decent'],
            rare: ['Superior', 'Enhanced', 'Fine', 'Polished'],
            epic: ['Exceptional', 'Masterwork', 'Elite', 'Prime'],
            legendary: ['Godlike', 'Mythical', 'Ancient', 'Legendary']
        };
        
        const typeNames = {
            helmet: 'Helmet',
            torso: 'Jacket',
            legs: 'Pants',
            shoes: 'Sneakers',
            board: 'Deck'
        };
        
        const prefix = prefixes[rarity][Math.floor(Math.random() * prefixes[rarity].length)];
        const name = typeNames[type];
        
        return `${prefix} ${name}`;
    }
    
    generateRandomCustomization(type, rarity) {
        const rarityData = this.getRarityData(rarity);
        
        // Random colors
        const colors = [
            '#FF0000', '#00FF00', '#0000FF', '#FFFF00', '#FF00FF', '#00FFFF',
            '#FF6600', '#8B00FF', '#FF1493', '#1E90FF', '#32CD32', '#FFD700'
        ];
        
        return {
            colors: {
                shell: colors[Math.floor(Math.random() * colors.length)],
                visor: '#000000',
                accent: rarityData.colorHex
            },
            material: ['standard', 'glossy', 'metallic', 'chrome'][Math.floor(Math.random() * 4)],
            decal: { image: null, scale: 1, rotation: 0, opacity: 100 },
            elements: [],
            elementScale: 1
        };
    }
    
    // ===================================
    // LOOT DROPS (Hook into enemies)
    // ===================================
    
    rollLootDrop(enemy) {
        // Base drop chance + enemy modifiers
        const dropChance = 0.3; // 30% base drop rate
        
        if (Math.random() < dropChance) {
            const loot = this.generateRandomLoot(enemy.level || 1);
            this.createLootPickup(enemy.mesh.position.clone(), loot);
            
            console.log(`💎 ${enemy.constructor.name} dropped: ${loot.name}`);
            return loot;
        }
        
        return null;
    }
    
    createLootPickup(position, item) {
        const rarityData = this.getRarityData(item.rarity);
        
        // Create 3D loot cube that spins
        const geometry = new THREE.BoxGeometry(0.5, 0.5, 0.5);
        const material = new THREE.MeshStandardMaterial({
            color: rarityData.color,
            emissive: rarityData.color,
            emissiveIntensity: 0.3,
            metalness: 0.8,
            roughness: 0.2
        });
        
        const lootMesh = new THREE.Mesh(geometry, material);
        lootMesh.position.copy(position);
        lootMesh.position.y += 1; // Float above ground
        lootMesh.castShadow = true;
        
        // Store item data on mesh
        lootMesh.userData.item = item;
        lootMesh.userData.isLoot = true;
        lootMesh.userData.spinSpeed = 0.02 + Math.random() * 0.02;
        
        this.engine.scene.add(lootMesh);
        
        // Add to tracking array
        if (!this.engine.lootPickups) {
            this.engine.lootPickups = [];
        }
        this.engine.lootPickups.push(lootMesh);
        
        return lootMesh;
    }
    
    // ===================================
    // UPDATE & COLLISION
    // ===================================
    
    update() {
        // Update loot pickups (spin animation)
        if (this.engine.lootPickups) {
            for (let i = this.engine.lootPickups.length - 1; i >= 0; i--) {
                const loot = this.engine.lootPickups[i];
                
                // Spin animation
                loot.rotation.y += loot.userData.spinSpeed;
                loot.position.y += Math.sin(Date.now() * 0.003 + i) * 0.005; // Float bobbing
                
                // Check player collision
                if (this.engine.player) {
                    const distance = loot.position.distanceTo(this.engine.player.position);
                    
                    if (distance < 2) {
                        // PICKUP!
                        this.pickupLoot(loot, i);
                    }
                }
            }
        }
    }
    
    pickupLoot(lootMesh, index) {
        const item = lootMesh.userData.item;
        
        // Add to inventory
        const success = this.addToInventory(item);
        
        if (success) {
            // Remove from scene
            this.engine.scene.remove(lootMesh);
            this.engine.lootPickups.splice(index, 1);
            
            // Visual feedback
            console.log(`✨ PICKED UP: ${item.name} (${item.rarity})`);
            
            // TODO: Add UI notification
        } else {
            console.warn('Inventory full! Cannot pickup item.');
            // TODO: Show "Inventory Full" message
        }
    }
    
    // ===================================
    // VISUAL GEAR LOADING (3D Models)
    // ===================================
    
    applyVisualGear(item) {
        // Load 3D model based on item type and customization
        switch(item.type) {
            case 'helmet':
                this.loadHelmet(item);
                break;
            case 'torso':
                this.loadTorso(item);
                break;
            case 'legs':
                this.loadLegs(item);
                break;
            case 'shoes':
                this.loadShoes(item);
                break;
            case 'board':
                this.loadBoard(item);
                break;
        }
    }
    
    removeVisualGear(slot) {
        // Remove 3D model for that slot
        // TODO: Implementation depends on how models are attached
        console.log(`🚫 Removed visual gear: ${slot}`);
    }
    
    loadHelmet(item) {
        // Use HelmetLoader to apply helmet
        if (this.engine.helmetLoader) {
            // Convert item customization to helmet format
            const helmetData = {
                name: item.name,
                ...item.customization
            };
            
            this.engine.helmetLoader.buildHelmet(helmetData);
        }
    }
    
    loadTorso(item) {
        // TODO: Create torso loader similar to helmet
        console.log('🎽 Loading torso:', item.name);
    }
    
    loadLegs(item) {
        // TODO: Create legs loader
        console.log('👖 Loading legs:', item.name);
    }
    
    loadShoes(item) {
        // TODO: Create shoes loader
        console.log('👟 Loading shoes:', item.name);
    }
    
    loadBoard(item) {
        // TODO: Create board loader
        console.log('🛹 Loading board:', item.name);
    }
    
    // ===================================
    // SAVE/LOAD SYSTEM
    // ===================================
    
    saveGearState() {
        const state = {
            equipped: this.equipped,
            inventory: this.inventory
        };
        
        localStorage.setItem('applesauce_gear', JSON.stringify(state));
        console.log('💾 Gear saved');
    }
    
    loadGearState() {
        const saved = localStorage.getItem('applesauce_gear');
        
        if (!saved) {
            console.log('No saved gear found');
            return false;
        }
        
        try {
            const state = JSON.parse(saved);
            
            this.equipped = state.equipped || {};
            this.inventory = state.inventory || [];
            
            // Reapply all equipped gear
            for (let slot in this.equipped) {
                if (this.equipped[slot]) {
                    this.applyVisualGear(this.equipped[slot]);
                }
            }
            
            this.recalculateStats();
            this.recalculateInventoryCapacity();
            
            console.log('✅ Gear loaded');
            return true;
        } catch (error) {
            console.error('Failed to load gear:', error);
            return false;
        }
    }
    
    // ===================================
    // CRAFTING SYSTEM (5 → 1 Upgrade)
    // ===================================
    
    craftUpgrade(items) {
        // Must be exactly 5 items
        if (items.length !== 5) {
            console.error('Crafting requires exactly 5 items');
            return null;
        }
        
        // All items must be same rarity
        const rarity = items[0].rarity;
        const sameRarity = items.every(item => item.rarity === rarity);
        
        if (!sameRarity) {
            console.error('All items must be same rarity');
            return null;
        }
        
        // Can't upgrade legendary
        if (rarity === 'legendary') {
            console.error('Cannot upgrade legendary items');
            return null;
        }
        
        // Get next rarity tier
        const rarityOrder = ['common', 'uncommon', 'rare', 'epic', 'legendary'];
        const currentIndex = rarityOrder.indexOf(rarity);
        const nextRarity = rarityOrder[currentIndex + 1];
        
        // Determine output type (most common type in input)
        const typeCounts = {};
        items.forEach(item => {
            typeCounts[item.type] = (typeCounts[item.type] || 0) + 1;
        });
        const outputType = Object.keys(typeCounts).reduce((a, b) => 
            typeCounts[a] > typeCounts[b] ? a : b
        );
        
        // Create upgraded item
        const upgradedItem = this.generateRandomLoot(1, nextRarity);
        upgradedItem.type = outputType;
        upgradedItem.name = this.generateItemName(outputType, nextRarity);
        
        // Remove input items from inventory
        items.forEach(item => {
            this.removeFromInventory(item.id);
        });
        
        // Add upgraded item
        this.addToInventory(upgradedItem);
        
        console.log(`⚡ CRAFTED: ${upgradedItem.name} (${nextRarity})`);
        
        return upgradedItem;
    }
    
    // ===================================
    // CLEANUP
    // ===================================
    
    clear() {
        // Remove all loot pickups from scene
        if (this.engine.lootPickups) {
            this.engine.lootPickups.forEach(loot => {
                this.engine.scene.remove(loot);
            });
            this.engine.lootPickups = [];
        }
        
        console.log('🎽 Gear module cleared');
    }
}
