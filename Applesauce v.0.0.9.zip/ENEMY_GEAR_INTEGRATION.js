/**
 * ENEMIES + GEAR INTEGRATION
 * This file shows the exact modifications needed to make enemies drop gear
 */

// ============================================
// MODIFIED ApplesauceEnemies Class
// ============================================
// Replace your killEnemy function with this enhanced version:

class ApplesauceEnemies {
    // ... existing constructor and methods ...
    
    killEnemy(enemy, engine) {
        enemy.isDead = true;
        enemy.deathTimer = 180; // 3 seconds
        this.kills++;
        
        // Existing gore effects
        if (engine.modules.gore) {
            const velocity = new THREE.Vector3(
                Math.sin(engine.state.rotation) * engine.state.speed,
                0,
                Math.cos(engine.state.rotation) * engine.state.speed
            );
            
            // Use gear stats for gore if available
            const bloodMultiplier = engine.state.gearStats?.bloodAmount || 1;
            const baseParticles = Math.abs(engine.state.speed) > 0.5 ? 50 : 30;
            const particleCount = Math.floor(baseParticles * bloodMultiplier);
            
            if (Math.abs(engine.state.speed) > 0.5) {
                engine.modules.gore.createMassiveSplatter(
                    enemy.mesh.position.clone(), 
                    velocity,
                    particleCount // Enhanced by gear!
                );
            } else {
                engine.modules.gore.createBloodSplatter(
                    enemy.mesh.position.clone(), 
                    velocity, 
                    particleCount // Enhanced by gear!
                );
                engine.modules.gore.createGibs(enemy.mesh.position.clone(), velocity, 5);
            }
        }
        
        // NEW: Loot drop system
        if (engine.modules.gear) {
            engine.modules.gear.rollLootDrop(enemy);
        }
        
        // Hide mesh
        enemy.mesh.visible = false;
        
        console.log('💀 ROADKILL!');
    }
}


// ============================================
// BOSS LOOT DROPS
// ============================================
// Bosses should have better loot! Add this to your Boss class:

class Boss extends Enemy {
    // ... existing methods ...
    
    // Override the rollLootDrop to guarantee good loot
    static rollBossLoot(boss, engine) {
        if (!engine.modules.gear) return;
        
        // Bosses ALWAYS drop loot
        // Higher chance for rare+ items
        const roll = Math.random();
        let rarity;
        
        if (roll < 0.1) rarity = 'legendary';      // 10%
        else if (roll < 0.3) rarity = 'epic';       // 20%
        else if (roll < 0.6) rarity = 'rare';       // 30%
        else rarity = 'uncommon';                   // 40%
        
        const loot = engine.modules.gear.generateRandomLoot(boss.level || 10, rarity);
        engine.modules.gear.createLootPickup(boss.mesh.position.clone(), loot);
        
        console.log(`👑 BOSS DROPPED: ${loot.name} (${loot.rarity})`);
        return loot;
    }
}

// Call this in your boss defeat logic:
/*
takeDamage(amount) {
    this.health -= amount;
    this.damageFlashTimer = 10;
    
    if (this.health <= 0) {
        this.isDead = true;
        this.deathTimer = 300;
        
        // Boss drops guaranteed loot!
        Boss.rollBossLoot(this, this.engine);
        
        console.log('🎉 BOSS DEFEATED!');
    }
}
*/


// ============================================
// ENEMY VARIANTS WITH GEAR BONUSES
// ============================================
// Create different enemy types that have different loot tables

class ArmoredEnemy extends Enemy {
    constructor(config, engine) {
        super(config, engine);
        this.health = 3; // Takes multiple hits
        this.color = 0x888888; // Gray armored
        this.gearBonus = 'rare'; // Always drops rare+
    }
}

class SpeedyEnemy extends Enemy {
    constructor(config, engine) {
        super(config, engine);
        this.speed = 0.06; // 3x faster
        this.color = 0x00FFFF; // Cyan
        this.gearBonus = 'uncommon'; // Drops uncommon+
    }
}

class TankEnemy extends Enemy {
    constructor(config, engine) {
        super(config, engine);
        this.health = 5;
        this.speed = 0.01; // Slow
        this.color = 0xFF00FF; // Magenta
        this.gearBonus = 'epic'; // Drops epic+
    }
}

// Use enemy types in rollLootDrop:
/*
rollLootDrop(enemy) {
    const dropChance = 0.3;
    
    if (Math.random() < dropChance) {
        // Check if enemy has special loot bonus
        const minRarity = enemy.gearBonus || null;
        const loot = this.generateRandomLoot(enemy.level || 1, minRarity);
        this.createLootPickup(enemy.mesh.position.clone(), loot);
        
        console.log(`💎 ${enemy.constructor.name} dropped: ${loot.name}`);
        return loot;
    }
    
    return null;
}
*/


// ============================================
// LEVEL INTEGRATION EXAMPLE
// ============================================
// Example of a complete level setup with gear:

function initLevel_Tutorial() {
    const engine = new ApplesauceCore({
        goreEnabled: true,
        maxSpeed: 1.0,
        hillHeight: 40
    });
    
    // Initialize modules
    engine.modules.gore = new ApplesauceGore(engine);
    engine.modules.enemies = new ApplesauceEnemies(engine);
    engine.modules.gear = new ApplesauceGear(engine);
    
    // Load saved gear
    engine.modules.gear.loadGearState();
    
    // Create player with helmet
    engine.player = createPlayer();
    engine.helmetLoader = new HelmetLoader(engine.scene, engine.player);
    engine.helmetLoader.loadHelmet();
    
    // Spawn enemies that drop loot
    engine.modules.enemies.spawnLine(0, 50, 5);
    
    // Main game loop
    function animate() {
        requestAnimationFrame(animate);
        
        if (engine.state.paused) return;
        
        // Update all modules
        engine.update();
        engine.modules.gore.update();
        engine.modules.enemies.update(engine);
        engine.modules.gear.update(); // NEW: Update gear system
        
        engine.renderer.render(engine.scene, engine.camera);
    }
    
    animate();
    
    return engine;
}


// ============================================
// GAMEPLAY INTEGRATION EXAMPLES
// ============================================

// Use gear stats in jump mechanics
function handleJump(engine) {
    if (!engine.state.grounded || engine.state.jumping) return;
    
    const baseJump = 0.5;
    const jumpBonus = engine.state.gearStats?.jumpBonus || 0;
    
    engine.state.jumpVelocity = baseJump * (1 + jumpBonus);
    engine.state.jumping = true;
    engine.state.grounded = false;
    
    console.log(`🦘 Jump power: ${(1 + jumpBonus).toFixed(2)}x`);
}

// Use gear stats in trick scoring
function awardTrickPoints(engine, trickName, baseScore) {
    const scoreBonus = engine.state.gearStats?.trickScoreBonus || 0;
    const comboBonus = engine.state.gearStats?.comboMultiplier || 0;
    
    const bonusedScore = baseScore * (1 + scoreBonus);
    const finalScore = bonusedScore * (1 + engine.state.combo + comboBonus);
    
    engine.state.score += Math.floor(finalScore);
    
    console.log(`✨ ${trickName}: ${Math.floor(finalScore)} pts (${(scoreBonus * 100).toFixed(0)}% gear bonus)`);
}

// Use gear stats in kickflip
function performKickflip(engine) {
    if (!engine.state.canTrick || !engine.state.jumping) return;
    
    const baseSpinSpeed = 0.2;
    const kickflipBonus = engine.state.gearStats?.kickflipSpeed || 0;
    
    engine.state.spinning = true;
    engine.state.spinSpeed = baseSpinSpeed * (1 + kickflipBonus);
    engine.state.canTrick = false;
    
    console.log(`🌀 Kickflip speed: ${(1 + kickflipBonus).toFixed(2)}x`);
}

// Use gear stats in air control
function handleAirMovement(engine, deltaX) {
    if (engine.state.grounded) return;
    
    const baseAirControl = 0.02;
    const airBonus = engine.state.gearStats?.airControl || 0;
    
    const airControl = baseAirControl * (1 + airBonus);
    engine.player.position.x += deltaX * airControl;
}


// ============================================
// HUD UPDATES
// ============================================
// Show gear stats in your HUD

function updateGearHUD(engine) {
    const stats = engine.modules.gear.totalStats;
    
    // Speed indicator
    const speedBonus = (stats.speedBonus * 100).toFixed(0);
    document.getElementById('speed-bonus').textContent = 
        speedBonus > 0 ? `+${speedBonus}% SPEED` : '';
    
    // Jump indicator
    const jumpBonus = (stats.jumpBonus * 100).toFixed(0);
    document.getElementById('jump-bonus').textContent = 
        jumpBonus > 0 ? `+${jumpBonus}% JUMP` : '';
    
    // Blood gore indicator
    const bloodBonus = (stats.bloodAmount * 100).toFixed(0);
    document.getElementById('gore-bonus').textContent = 
        bloodBonus > 0 ? `${bloodBonus}% MORE GORE` : '';
    
    // Inventory counter
    const gear = engine.modules.gear;
    document.getElementById('inventory-count').textContent = 
        `Inventory: ${gear.inventory.length}/${gear.maxInventorySlots}`;
}


// ============================================
// KEYBOARD SHORTCUTS
// ============================================
// Add quick access to gear functions

document.addEventListener('keydown', (e) => {
    if (!engine.modules.gear) return;
    
    // Press 'I' to open inventory
    if (e.key === 'i' || e.key === 'I') {
        openInventoryUI(engine);
    }
    
    // Press 'C' to craft
    if (e.key === 'c' || e.key === 'C') {
        openCraftingUI(engine);
    }
    
    // Press 'G' to view gear stats
    if (e.key === 'g' || e.key === 'G') {
        console.log('=== GEAR STATS ===');
        console.log(engine.modules.gear.totalStats);
    }
});


// ============================================
// SAVE ON EXIT
// ============================================
// Auto-save gear when leaving level

window.addEventListener('beforeunload', () => {
    if (engine && engine.modules.gear) {
        engine.modules.gear.saveGearState();
    }
});


// ============================================
// TESTING COMMANDS
// ============================================
// Useful console commands for testing

// Spawn test loot
window.spawnTestLoot = function(rarity = 'legendary') {
    const loot = engine.modules.gear.generateRandomLoot(10, rarity);
    engine.modules.gear.createLootPickup(
        engine.player.position.clone().add(new THREE.Vector3(0, 0, 5)),
        loot
    );
    console.log('Spawned test loot:', loot.name);
};

// Give full legendary set
window.giveGodGear = function() {
    const types = ['helmet', 'torso', 'legs', 'shoes', 'board'];
    types.forEach(type => {
        const item = engine.modules.gear.generateRandomLoot(999, 'legendary');
        item.type = type;
        item.name = `GOD-TIER ${type.toUpperCase()}`;
        item.stats = {
            speedBonus: 2.0,
            jumpBonus: 2.0,
            trickScoreBonus: 2.0,
            bloodAmount: 5.0,
            comboMultiplier: 2.0
        };
        engine.modules.gear.equipItem(item);
    });
    console.log('🔥 GOD GEAR ACTIVATED');
};

// Clear inventory
window.clearInventory = function() {
    engine.modules.gear.inventory = [];
    console.log('Inventory cleared');
};

// List all gear
window.listGear = function() {
    console.log('=== EQUIPPED ===');
    console.log(engine.modules.gear.equipped);
    console.log('=== INVENTORY ===');
    console.log(engine.modules.gear.inventory);
    console.log('=== STATS ===');
    console.log(engine.modules.gear.totalStats);
};
