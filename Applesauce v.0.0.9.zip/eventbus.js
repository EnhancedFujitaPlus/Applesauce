class EventBus {
    constructor() {
        this.events = {};
    }
    
    on(event, callback) {
        if (!this.events[event]) this.events[event] = [];
        this.events[event].push(callback);
    }
    
    emit(event, data) {
        if (this.events[event]) {
            this.events[event].forEach(cb => cb(data));
        }
    }
}

// Usage:
eventBus.on('enemyKilled', (data) => {
    goreSystem.createBloodExplosion(data.position);
    scoreSystem.addPoints(100);
    objectiveTracker.incrementKills();
});

// Instead of calling everything directly:
eventBus.emit('enemyKilled', { position: enemy.position });