// PhysicsEntity.js
class PhysicsEntity {
    constructor(config) {
        this.position = config.position || new THREE.Vector3(0, 0, 0);
        this.velocity = config.velocity || new THREE.Vector3(0, 0, 0);
        this.size = config.size || 1;
        this.color = config.color || 0xFF0000;
        this.lifetime = config.lifetime || 600;
        this.damage = config.damage || 10;
        this.collisionRadius = config.collisionRadius || this.size * 0.5;
        this.type = config.type || 'generic';
        
        this.gravity = 0.015;
        this.friction = 0.95;
        this.bounciness = 0.3;
        
        this.createMesh();
    }
    
    createMesh() {
        const geometry = new THREE.SphereGeometry(this.size * 0.5, 8, 8);
        const material = new THREE.MeshLambertMaterial({ 
            color: this.color 
        });
        this.mesh = new THREE.Mesh(geometry, material);
        this.mesh.position.copy(this.position);
    }
    
    update(scene) {
        // Apply physics
        this.velocity.y -= this.gravity;
        this.position.add(this.velocity);
        this.mesh.position.copy(this.position);
        
        // Rotation for visual effect
        this.mesh.rotation.x += this.velocity.length() * 0.1;
        this.mesh.rotation.z += this.velocity.length() * 0.1;
        
        // Ground collision
        if (this.position.y < 0.5) {
            this.position.y = 0.5;
            this.velocity.y *= -this.bounciness;
            this.velocity.x *= this.friction;
            this.velocity.z *= this.friction;
            
            this.onGroundHit(scene);
        }
        
        this.lifetime--;
        return this.lifetime > 0;
    }
    
    onGroundHit(scene) {
        // Override in subclasses
    }
}