// PropFactory.js - CREATES props
class PropFactory {
    static createTree(height) {
        const trunk = new THREE.Mesh(
            new THREE.CylinderGeometry(0.3, 0.4, height),
            new THREE.MeshLambertMaterial({ color: 0x8B4513 })
        );
        // ...
        return group;
    }
    
    static createBench() { /* ... */ }
    static createRail() { /* ... */ }
}

// PropManager.js - PLACES props
class PropManager {
    constructor(scene, config) {
        this.scene = scene;
        this.config = config;
        this.props = [];
    }
    
    populate() {
        this.placeTrees(this.config.trees);
        this.placeBenches(this.config.benches);
        // ...
    }
    
    placeTrees({ count, radius }) {
        for (let i = 0; i < count; i++) {
            const angle = Math.random() * Math.PI * 2;
            const distance = Math.random() * radius;
            const tree = PropFactory.createTree(8 + Math.random() * 6);
            tree.position.set(
                Math.cos(angle) * distance,
                0,
                Math.sin(angle) * distance
            );
            this.scene.add(tree);
            this.props.push(tree);
        }
    }
}