/**
 * APPLESAUCE Core Engine v3.0
 * Modular architecture for easy level expansion
 */

class ApplesauceCore {
    constructor(config = {}) {
        // Apply configuration
        this.config = {
            goreEnabled: config.goreEnabled !== false, // Default true
            maxSpeed: config.maxSpeed || 1.2,
            hillHeight: config.hillHeight || 60,
            hillLength: config.hillLength || 250,
            ...config
        };

        // Core Three.js setup
        this.scene = new THREE.Scene();
        this.scene.fog = new THREE.Fog(0x87CEEB, 100, 400);
        this.scene.background = new THREE.Color(0x87CEEB);
        
        this.camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
        
        this.renderer = new THREE.WebGLRenderer({ antialias: true });
        this.renderer.setSize(window.innerWidth, window.innerHeight);
        this.renderer.shadowMap.enabled = true;
        this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
        document.body.appendChild(this.renderer.domElement);
        
        // Materials library
        this.materials = {
            concrete: new THREE.MeshLambertMaterial({ color: 0x808080 }),
            grass: new THREE.MeshLambertMaterial({ color: 0x2d5a2d }),
            metal: new THREE.MeshStandardMaterial({ color: 0x888888, metalness: 0.8, roughness: 0.2 }),
            wood: new THREE.MeshLambertMaterial({ color: 0x8B4513 }),
            graffitiColors: [0xFF1493, 0x00FF00, 0xFFD700, 0xFF4500, 0x00FFFF]
        };
        
        // Game arrays
        this.obstacles = [];
        this.rails = [];
        this.keys = {};
        
        // Core game state
        this.state = {
            speed: 0,
            maxSpeed: this.config.maxSpeed,
            acceleration: 0.03,
            friction: 0.98,
            turnSpeed: 0.03,
            rotation: 0,
            jumping: false,
            jumpVelocity: 0,
            gravity: -0.025,
            grounded: true,
            grinding: false,
            currentRail: null,
            score: 0,
            combo: 0,
            comboTimer: 0,
            currentTrick: '',
            trickTimer: 0,
            canTrick: true,
            spinning: false,
            spinRotation: 0,
            kickflips: 0,
            attemptingKickflip: false,
            paused: false
        };
        
        // Module hooks (will be populated by feature modules)
        this.modules = {
            gore: null,
            dialogue: null,
            enemies: null,
            objectives: null
        };
        
        // Player reference
        this.player = null;
        this.deck = null;
        
        // Animation
        this.animationId = null;
        this.isRunning = false;
        
        // Setup core systems
        this._setupLighting();
        this._setupControls();
        this._setupResize();
        
        console.log('🛹 APPLESAUCE Core Engine initialized');
    }
    
    // ===================================
    // LIGHTING SETUP
    // ===================================
    _setupLighting() {
        const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
        this.scene.add(ambientLight);
        
        const sun = new THREE.DirectionalLight(0xffffff, 0.8);
        sun.position.set(50, 200, 50);
        sun.castShadow = true;
        sun.shadow.camera.left = -150;
        sun.shadow.camera.right = 150;
        sun.shadow.camera.top = 150;
        sun.shadow.camera.bottom = -150;
        sun.shadow.mapSize.width = 2048;
        sun.shadow.mapSize.height = 2048;
        this.scene.add(sun);
    }
    
    // ===================================
    // CONTROLS SETUP
    // ===================================
    _setupControls() {
        document.addEventListener('keydown', (e) => {
            this.keys[e.key.toLowerCase()] = true;
            
            // ESC for pause
            if (e.key === 'Escape') {
                this.togglePause();
                return;
            }
            
            // Don't process game controls if paused or dialogue active
            if (this.state.paused || (this.modules.dialogue && this.modules.dialogue.isActive)) {
                return;
            }
            
            // Space for jump/ollie
            if (e.key === ' ') {
                e.preventDefault();
                this.handleJump();
            }
            
            // Trick keys (Q, E, B, Z)
            if (!this.state.grounded && this.state.canTrick) {
                this.handleTrickInput(e.key.toLowerCase());
            }
        });
        
        document.addEventListener('keyup', (e) => {
            this.keys[e.key.toLowerCase()] = false;
        });
        
        // Pointer lock for camera control
        this.renderer.domElement.addEventListener('click', () => {
            this.renderer.domElement.requestPointerLock();
        });
    }
    
    handleJump() {
        if (this.state.grinding) {
            // Jump off grind
            this.state.grinding = false;
            this.state.currentRail = null;
            this.state.jumpVelocity = 0.35;
            this.state.jumping = true;
            this.state.grounded = false;
            this.state.canTrick = true;
        } else if (this.state.grounded && !this.state.jumping) {
            // Regular ollie
            this.state.jumping = true;
            this.state.jumpVelocity = 0.35;
            this.state.grounded = false;
            this.state.canTrick = true;
        }
    }
    
    handleTrickInput(key) {
        let trickName = '';
        
        switch(key) {
            case 'q':
                trickName = 'KICKFLIP!';
                this.state.attemptingKickflip = true;
                break;
            case 'e':
                trickName = 'HEELFLIP!';
                this.state.attemptingKickflip = false;
                break;
            case 'b':
                trickName = 'IMPOSSIBLE';
                this.state.attemptingKickflip = false;
                break;
            case 'z':
                trickName = '360 FLIP!';
                this.state.attemptingKickflip = false;
                break;
        }
        
        if (trickName) {
            this.state.currentTrick = trickName;
            this.state.spinning = true;
            this.state.spinRotation = 0;
            this.state.combo++;
            this.state.trickTimer = 60;
            this.state.canTrick = false;
            this.state.score += 100 * this.state.combo;
        }
    }
    
    togglePause() {
        this.state.paused = !this.state.paused;
        console.log(this.state.paused ? 'Game Paused' : 'Game Resumed');
    }
    
    _setupResize() {
        window.addEventListener('resize', () => {
            this.camera.aspect = window.innerWidth / window.innerHeight;
            this.camera.updateProjectionMatrix();
            this.renderer.setSize(window.innerWidth, window.innerHeight);
        });
    }
    
    // ===================================
    // TERRAIN HELPERS
    // ===================================
    getTerrainHeight(x, z) {
        const hillLength = this.config.hillLength;
        const hillHeight = this.config.hillHeight;
        
        if (z < hillLength) {
            const normalizedZ = z / hillLength;
            return (1 - normalizedZ) * hillHeight;
        }
        return 0;
    }
    
    // ===================================
    // PLAYER CREATION
    // ===================================
    createPlayer(x = 0, z = 10) {
        this.player = new THREE.Group();
        
        // Deck
        const deckGeo = new THREE.BoxGeometry(0.8, 0.1, 2.5);
        const deckMat = new THREE.MeshLambertMaterial({ color: 0xFF1493 });
        this.deck = new THREE.Mesh(deckGeo, deckMat);
        this.deck.position.y = 0.3;
        this.player.add(this.deck);
        
        // Wheels
        for (let pos of [[-0.3, 0.15, -0.8], [0.3, 0.15, -0.8], [-0.3, 0.15, 0.8], [0.3, 0.15, 0.8]]) {
            const wheelGeo = new THREE.CylinderGeometry(0.15, 0.15, 0.1, 12);
            const wheelMat = new THREE.MeshLambertMaterial({ color: 0x222222 });
            const wheel = new THREE.Mesh(wheelGeo, wheelMat);
            wheel.position.set(...pos);
            wheel.rotation.z = Math.PI / 2;
            this.player.add(wheel);
        }
        
        // Simple rider body (using cylinder since CapsuleGeometry doesn't exist in r128)
        const bodyGeo = new THREE.CylinderGeometry(0.3, 0.3, 1.2, 8);
        const bodyMat = new THREE.MeshLambertMaterial({ color: 0x3366CC });
        const body = new THREE.Mesh(bodyGeo, bodyMat);
        body.position.set(0, 1.5, 0);
        this.player.add(body);
        
        // Head
        const headGeo = new THREE.SphereGeometry(0.3, 16, 16);
        const headMat = new THREE.MeshLambertMaterial({ color: 0xFFDBAC });
        const head = new THREE.Mesh(headGeo, headMat);
        head.position.set(0, 2.5, 0);
        this.player.add(head);
        
        // Position player
        this.player.position.set(x, this.getTerrainHeight(x, z) + 0.5, z);
        this.player.castShadow = true;
        this.scene.add(this.player);
        
        console.log('🛹 Player created');
        return this.player;
    }
    
    // ===================================
    // OBSTACLE CREATION
    // ===================================
    createQuarterPipe(x, z, rotation = 0, width = 10) {
        const qp = new THREE.Group();
        
        const curve = new THREE.QuadraticBezierCurve3(
            new THREE.Vector3(0, 0, 0),
            new THREE.Vector3(0, 3, 1.5),
            new THREE.Vector3(0, 3, 3)
        );
        
        const tubeGeo = new THREE.TubeGeometry(curve, 20, width / 2, 8, false);
        const tubeMat = this.materials.concrete;
        const tube = new THREE.Mesh(tubeGeo, tubeMat);
        tube.rotation.z = Math.PI / 2;
        tube.castShadow = true;
        tube.receiveShadow = true;
        qp.add(tube);
        
        qp.position.set(x, this.getTerrainHeight(x, z), z);
        qp.rotation.y = rotation;
        this.scene.add(qp);
        this.obstacles.push(qp);
    }
    
    createFunbox(x, z) {
        const funbox = new THREE.Group();
        
        // Platform
        const platformGeo = new THREE.BoxGeometry(8, 1, 8);
        const platform = new THREE.Mesh(platformGeo, this.materials.wood);
        platform.position.y = 0.5;
        platform.castShadow = true;
        platform.receiveShadow = true;
        funbox.add(platform);
        
        // Rails on edges
        this.createFunboxRail(funbox, -4, 1, 0, 8);
        this.createFunboxRail(funbox, 4, 1, 0, 8);
        
        funbox.position.set(x, this.getTerrainHeight(x, z), z);
        this.scene.add(funbox);
        this.obstacles.push(funbox);
    }
    
    createFunboxRail(parent, x, y, z, length) {
        const railGeo = new THREE.CylinderGeometry(0.1, 0.1, length, 8);
        const rail = new THREE.Mesh(railGeo, this.materials.metal);
        rail.position.set(x, y, z);
        rail.castShadow = true;
        parent.add(rail);
        this.rails.push(rail);
    }
    
    createLongRail(xOffset, zStart, zEnd, heightStart, heightEnd) {
        const length = Math.abs(zEnd - zStart);
        const railGeo = new THREE.CylinderGeometry(0.1, 0.1, length, 8);
        const rail = new THREE.Mesh(railGeo, this.materials.metal);
        
        const midZ = (zStart + zEnd) / 2;
        const midHeight = (heightStart + heightEnd) / 2;
        
        rail.position.set(xOffset, midHeight, midZ);
        rail.rotation.x = Math.PI / 2;
        rail.castShadow = true;
        
        this.scene.add(rail);
        this.rails.push(rail);
        this.obstacles.push(rail);
    }
    
    createFlatRail(x, z, length, rotation = 0) {
        const railGeo = new THREE.CylinderGeometry(0.1, 0.1, length, 8);
        const rail = new THREE.Mesh(railGeo, this.materials.metal);
        
        rail.position.set(x, this.getTerrainHeight(x, z) + 0.8, z);
        rail.rotation.x = Math.PI / 2;
        rail.rotation.y = rotation;
        rail.castShadow = true;
        
        this.scene.add(rail);
        this.rails.push(rail);
        this.obstacles.push(rail);
    }
    
    createLedge(x, z, length = 12, height = 1.2) {
        const ledgeGeo = new THREE.BoxGeometry(1, height, length);
        const ledge = new THREE.Mesh(ledgeGeo, this.materials.concrete);
        
        ledge.position.set(x, this.getTerrainHeight(x, z) + height / 2, z);
        ledge.castShadow = true;
        ledge.receiveShadow = true;
        
        this.scene.add(ledge);
        this.obstacles.push(ledge);
    }
    
    createStairs(x, z, rotation = 0) {
        const stairs = new THREE.Group();
        const steps = 6;
        
        for (let i = 0; i < steps; i++) {
            const stepGeo = new THREE.BoxGeometry(4, 0.2, 1);
            const step = new THREE.Mesh(stepGeo, this.materials.concrete);
            step.position.set(0, i * 0.2, i * 1);
            step.castShadow = true;
            step.receiveShadow = true;
            stairs.add(step);
        }
        
        stairs.position.set(x, this.getTerrainHeight(x, z), z);
        stairs.rotation.y = rotation;
        this.scene.add(stairs);
        this.obstacles.push(stairs);
    }
    
    // ===================================
    // GRINDING SYSTEM
    // ===================================
    checkGrinding() {
        if (this.state.grinding) return;
        if (!this.player) return;
        
        for (let rail of this.rails) {
            const worldPos = new THREE.Vector3();
            rail.getWorldPosition(worldPos);
            
            const dx = this.player.position.x - worldPos.x;
            const dy = this.player.position.y - worldPos.y;
            const dz = this.player.position.z - worldPos.z;
            
            const horizontalDist = Math.sqrt(dx * dx + dz * dz);
            
            if (horizontalDist < 1.5 && Math.abs(dy) < 1) {
                this.state.grinding = true;
                this.state.currentRail = rail;
                this.state.combo = Math.max(this.state.combo, 1);
                this.state.comboTimer = 10;
                this.state.currentTrick = 'GRINDING!';
                this.state.trickTimer = 999;
                this.player.position.y = worldPos.y;
                break;
            }
        }
    }
    
    // ===================================
    // PHYSICS UPDATE
    // ===================================
    updatePhysics() {
        if (!this.player || this.state.paused) return;
        
        // Skip physics if dialogue active
        if (this.modules.dialogue && this.modules.dialogue.isActive) {
            return;
        }
        
        // Movement controls
        if (this.keys['w'] || this.keys['arrowup']) {
            this.state.speed = Math.min(this.state.speed + this.state.acceleration, this.state.maxSpeed);
        }
        if (this.keys['s'] || this.keys['arrowdown']) {
            this.state.speed = Math.max(this.state.speed - this.state.acceleration, -this.state.maxSpeed * 0.5);
        }
        
        if (this.keys['a'] || this.keys['arrowleft']) {
            this.state.rotation += this.state.turnSpeed;
        }
        if (this.keys['d'] || this.keys['arrowright']) {
            this.state.rotation -= this.state.turnSpeed;
        }
        
        // Apply friction
        this.state.speed *= this.state.friction;
        
        // Movement
        const forward = new THREE.Vector3(
            Math.sin(this.state.rotation),
            0,
            Math.cos(this.state.rotation)
        );
        
        this.player.position.add(forward.multiplyScalar(this.state.speed));
        this.player.rotation.y = this.state.rotation;
        
        // Jump physics
        if (this.state.jumping || !this.state.grounded) {
            this.state.jumpVelocity += this.state.gravity;
            this.player.position.y += this.state.jumpVelocity;
        }
        
        // Ground collision
        const groundY = this.getTerrainHeight(this.player.position.x, this.player.position.z) + 0.5;
        
        if (this.player.position.y <= groundY && !this.state.grinding) {
            this.player.position.y = groundY;
            this.state.grounded = true;
            this.state.jumping = false;
            this.state.jumpVelocity = 0;
            
            // Land kickflip
            if (this.state.attemptingKickflip && this.state.spinning) {
                this.state.kickflips++;
                this.state.attemptingKickflip = false;
            }
        } else {
            this.state.grounded = false;
        }
        
        // Deck spin animation
        if (this.state.spinning && this.deck) {
            this.state.spinRotation += 0.3;
            if (this.state.spinRotation >= Math.PI * 2) {
                this.state.spinning = false;
                this.state.spinRotation = 0;
            }
            this.deck.rotation.x = this.state.spinRotation;
        } else if (this.deck) {
            this.deck.rotation.x = 0;
        }
        
        // Check grinding
        this.checkGrinding();
        
        // Grind scoring
        if (this.state.grinding) {
            this.state.score += 5;
            this.state.combo = Math.max(this.state.combo, 1);
            this.state.comboTimer = 10;
            
            // Check if still on rail
            if (this.state.currentRail) {
                const worldPos = new THREE.Vector3();
                this.state.currentRail.getWorldPosition(worldPos);
                const dx = this.player.position.x - worldPos.x;
                const dz = this.player.position.z - worldPos.z;
                const horizontalDist = Math.sqrt(dx * dx + dz * dz);
                
                if (horizontalDist > 4) {
                    this.state.grinding = false;
                    this.state.currentRail = null;
                    this.state.jumpVelocity = -0.1;
                }
            }
        }
        
        // Combo timer
        if (this.state.comboTimer > 0) {
            this.state.comboTimer--;
            if (this.state.comboTimer === 0 && this.state.grounded && !this.state.grinding) {
                this.state.combo = 0;
            }
        }
        
        // Trick timer
        if (this.state.trickTimer > 0) {
            this.state.trickTimer--;
            if (this.state.trickTimer === 0) {
                this.state.currentTrick = '';
            }
        }
    }
    
    // ===================================
    // CAMERA UPDATE
    // ===================================
    updateCamera() {
        if (!this.player) return;
        
        const cameraOffset = new THREE.Vector3(
            -Math.sin(this.state.rotation) * 10,
            7,
            -Math.cos(this.state.rotation) * 10
        );
        
        this.camera.position.lerp(
            this.player.position.clone().add(cameraOffset),
            0.1
        );
        
        this.camera.lookAt(this.player.position.clone().add(new THREE.Vector3(0, 1, 0)));
    }
    
    // ===================================
    // HUD UPDATE
    // ===================================
    updateHUD() {
        // Update basic stats
        const scoreEl = document.getElementById('score');
        if (scoreEl) scoreEl.textContent = `SCORE: ${Math.floor(this.state.score)}`;
        
        const comboEl = document.getElementById('combo');
        if (comboEl) comboEl.textContent = `COMBO: ${this.state.combo}x`;
        
        const trickEl = document.getElementById('trick');
        if (trickEl) trickEl.textContent = this.state.currentTrick;
        
        // Speed display with color coding
        const speedDisplay = Math.floor(Math.abs(this.state.speed) * 100);
        const speedEl = document.getElementById('speed');
        if (speedEl) {
            const isLethal = speedDisplay >= 20;
            speedEl.style.color = isLethal ? '#FF0000' : '#00FFFF';
            speedEl.textContent = isLethal ? `SPEED: ${speedDisplay} [LETHAL]` : `SPEED: ${speedDisplay}`;
        }
    }
    
    // ===================================
    // MAIN UPDATE LOOP
    // ===================================
    update() {
        if (this.state.paused) return;
        
        // Core physics
        this.updatePhysics();
        
        // Call module updates
        if (this.modules.enemies && this.modules.enemies.update) {
            this.modules.enemies.update(this);
        }
        
        if (this.modules.gore && this.modules.gore.update) {
            this.modules.gore.update(this);
        }
        
        if (this.modules.objectives && this.modules.objectives.update) {
            this.modules.objectives.update(this);
        }
        
        if (this.modules.dialogue && this.modules.dialogue.update) {
            this.modules.dialogue.update(this);
        }
        
        // Camera and HUD
        this.updateCamera();
        this.updateHUD();
    }
    
    // ===================================
    // ANIMATION LOOP
    // ===================================
    start() {
        if (this.isRunning) return;
        this.isRunning = true;
        
        const animate = () => {
            this.animationId = requestAnimationFrame(animate);
            this.update();
            this.renderer.render(this.scene, this.camera);
        };
        
        animate();
        console.log('🛹 Game started!');
    }
    
    stop() {
        if (!this.isRunning) return;
        this.isRunning = false;
        
        if (this.animationId) {
            cancelAnimationFrame(this.animationId);
            this.animationId = null;
        }
        
        console.log('🛹 Game stopped');
    }
    
    // ===================================
    // MODULE REGISTRATION
    // ===================================
    registerModule(name, module) {
        this.modules[name] = module;
        console.log(`📦 Module registered: ${name}`);
    }
}
