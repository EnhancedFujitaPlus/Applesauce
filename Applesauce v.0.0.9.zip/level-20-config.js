// level15-config.js
const Level15Config = {
    meta: {
        name: "OUTSIDE THE BOX",
        number: 20,
        theme: "urban"
    },
    
    objectives: {
        roadkill: { target: 10 },
        kickflips: { target: 5 },
        boss: { enabled: true }
    },
    
    world: {
        size: 500,
        segments: 150,
        lighting: {
            ambientColor: 0x666666,
            directionalColor: 0xffffff,
            fog: { color: 0x87CEEB, near: 10, far: 400 }
        },
        colors: {
            ground: 0x2d2d2d,
            grass: 0x1a4d1a
        }
    },
    
    props: {
        trees: { count: 200, radius: 200 },
        benches: { count: 40, radius: 150 },
        rails: { count: 25, radius: 120 },
        buildings: { count: 15, radius: 180 }
    },
    
    enemies: {
        normalEnemies: { count: 30, spawnRadius: 150 },
        boss: { 
            spawnAfterKills: 10,
            health: 5,
            speed: 0.08
        }
    },
    
    npcs: [
        {
            name: "Skate Guru",
            position: { x: -50, z: -50 },
            dialogue: [
                "Welcome to OUTSIDE THE BOX!",
                "Land some kickflips and rack up kills.",
                "The boss appears after 10 kills..."
            ]
        }
    ]
};