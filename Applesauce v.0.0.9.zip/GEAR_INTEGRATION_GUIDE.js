/**
 * APPLESAUCE GEAR MODULE - INTEGRATION GUIDE
 * 
 * This guide explains how to integrate the gear system into your APPLESAUCE game
 * and how it modifies gameplay through direct stat effects.
 */

// ============================================
// STEP 1: INITIALIZE GEAR MODULE
// ============================================

// In your level/game initialization:
const engine = new ApplesauceCore(config);

// Initialize gear module
engine.modules.gear = new ApplesauceGear(engine);

// Load saved gear (if any)
engine.modules.gear.loadGearState();


// ============================================
// STEP 2: HOOK INTO ENEMY DEATHS FOR LOOT DROPS
// ============================================

// Modify your ApplesauceEnemies killEnemy function:
/*
killEnemy(enemy, engine) {
    enemy.isDead = true;
    enemy.deathTimer = 180;
    this.kills++;
    
    // Gore effects (existing code)
    if (engine.modules.gore) {
        // ... gore code
    }
    
    // NEW: Roll for loot drop
    if (engine.modules.gear) {
        engine.modules.gear.rollLootDrop(enemy);
    }
    
    enemy.mesh.visible = false;
    console.log('💀 ROADKILL!');
}
*/


// ============================================
// STEP 3: UPDATE GEAR IN GAME LOOP
// ============================================

// In your main game loop / animate function:
/*
function animate() {
    requestAnimationFrame(animate);
    
    if (engine.state.paused) return;
    
    // ... existing game update code
    
    // Update gear module (handles loot pickup collisions)
    if (engine.modules.gear) {
        engine.modules.gear.update();
    }
    
    // ... rest of game loop
}
*/


// ============================================
// STEP 4: ACCESSING GEAR STATS IN GAMEPLAY
// ============================================

// The gear system stores calculated bonuses in engine.state.gearStats
// Use these to modify gameplay calculations:

// EXAMPLE: Jump with gear bonus
/*
function jump() {
    if (!engine.state.grounded) return;
    
    const baseJump = 0.5;
    const jumpBonus = engine.state.gearStats?.jumpBonus || 0;
    
    engine.state.jumpVelocity = baseJump * (1 + jumpBonus);
    engine.state.jumping = true;
    engine.state.grounded = false;
}
*/

// EXAMPLE: Trick scoring with gear bonus
/*
function completeTrick(baseTrickScore) {
    const scoreBonus = engine.state.gearStats?.trickScoreBonus || 0;
    const comboBonus = engine.state.gearStats?.comboMultiplier || 0;
    
    const finalScore = baseTrickScore * (1 + scoreBonus);
    engine.state.score += finalScore * (1 + engine.state.combo + comboBonus);
}
*/

// EXAMPLE: Blood splatter with gear bonus
/*
function createBloodSplatter(position, velocity) {
    const baseParticles = 20;
    const bloodBonus = engine.state.gearStats?.bloodAmount || 0;
    
    const particleCount = Math.floor(baseParticles * (1 + bloodBonus));
    
    // ... create particles
}
*/

// EXAMPLE: Grinding with gear bonus
/*
function updateGrinding() {
    if (!engine.state.grinding) return;
    
    const baseGrindSpeed = 0.8;
    const grindBonus = engine.state.gearStats?.grindSpeed || 0;
    
    engine.state.speed = baseGrindSpeed * (1 + grindBonus);
}
*/


// ============================================
// STEP 5: INVENTORY UI ACCESS
// ============================================

// Access gear data for UI display:

// Get all equipped items
const equipped = engine.modules.gear.equipped;
console.log('Helmet:', equipped.helmet);
console.log('Torso:', equipped.torso);
console.log('Legs:', equipped.legs);
console.log('Shoes:', equipped.shoes);
console.log('Board:', equipped.board);

// Get inventory
const inventory = engine.modules.gear.inventory;
console.log(`Inventory: ${inventory.length}/${engine.modules.gear.maxInventorySlots}`);

// Get total stats
const stats = engine.modules.gear.totalStats;
console.log('Speed Bonus:', stats.speedBonus);
console.log('Jump Bonus:', stats.jumpBonus);
console.log('Blood Amount:', stats.bloodAmount);


// ============================================
// EXAMPLE: MANUALLY CREATING GEAR
// ============================================

// Create a custom item
const customHelmet = {
    id: 'my_custom_helmet_001',
    name: 'Demon Skull Helmet',
    type: 'helmet',
    rarity: 'legendary',
    
    stats: {
        speedBonus: 0.5,      // +50% max speed
        bloodAmount: 3.0,     // 3x blood particles
        trickScoreBonus: 0.8  // +80% trick points
    },
    
    customization: {
        colors: {
            shell: '#8B0000',
            visor: '#000000',
            accent: '#FF0000'
        },
        material: 'chrome',
        decal: { image: null, scale: 1, rotation: 0, opacity: 100 },
        elements: ['spikes', 'horns'],
        elementScale: 1.5
    },
    
    level: 10
};

// Add to inventory
engine.modules.gear.addToInventory(customHelmet);

// Or equip directly
engine.modules.gear.equipItem(customHelmet);


// ============================================
// EXAMPLE: TESTING LOOT GENERATION
// ============================================

// Generate random loot
const randomLoot = engine.modules.gear.generateRandomLoot(5); // Level 5 enemy
console.log('Generated:', randomLoot);

// Force specific rarity
const epicItem = engine.modules.gear.generateRandomLoot(10, 'epic');
console.log('Epic Item:', epicItem);


// ============================================
// EXAMPLE: CRAFTING 5 ITEMS INTO 1 UPGRADE
// ============================================

// Get 5 common items from inventory
const commonItems = engine.modules.gear.inventory.filter(
    item => item.rarity === 'common'
).slice(0, 5);

// Craft them into an uncommon item
if (commonItems.length === 5) {
    const upgraded = engine.modules.gear.craftUpgrade(commonItems);
    console.log('Crafted:', upgraded);
}


// ============================================
// EXAMPLE: SAVE/LOAD SYSTEM
// ============================================

// Save current gear state
engine.modules.gear.saveGearState();

// Load gear state (called on game start)
engine.modules.gear.loadGearState();


// ============================================
// STAT REFERENCE GUIDE
// ============================================

/**
 * AVAILABLE GEAR STATS:
 * 
 * MOVEMENT:
 * - speedBonus: Multiplies engine.state.maxSpeed
 * - accelerationBonus: Multiplies engine.state.acceleration
 * - turnBonus: Multiplies engine.state.turnSpeed
 * 
 * TRICKS:
 * - jumpBonus: Multiplies jump velocity
 * - trickScoreBonus: Multiplies trick point values
 * - comboMultiplier: Additive combo bonus (stacks with engine.state.combo)
 * 
 * GORE:
 * - bloodAmount: Multiplies particle count in blood splatters
 * - splatRadius: Multiplies splatter spread radius
 * 
 * SPECIAL:
 * - grindSpeed: Speed multiplier during rail grinding
 * - airControl: Air movement control bonus (0.0 to 1.0)
 * - kickflipSpeed: Kickflip rotation speed multiplier
 * 
 * All stats are ADDITIVE across equipped items.
 * Example: Helmet (+0.2 speed) + Torso (+0.3 speed) = +0.5 speed total
 */


// ============================================
// RARITY SYSTEM
// ============================================

/**
 * COMMON (Gray):
 * - Stat Multiplier: 1.0x
 * - Inventory Slots: +1
 * - Drop Chance: 50%
 * 
 * UNCOMMON (Green):
 * - Stat Multiplier: 1.3x
 * - Inventory Slots: +2
 * - Drop Chance: 30%
 * 
 * RARE (Blue):
 * - Stat Multiplier: 1.6x
 * - Inventory Slots: +4
 * - Drop Chance: 15%
 * 
 * EPIC (Purple):
 * - Stat Multiplier: 2.0x
 * - Inventory Slots: +7
 * - Drop Chance: 4%
 * 
 * LEGENDARY (Gold):
 * - Stat Multiplier: 2.5x
 * - Inventory Slots: +10
 * - Drop Chance: 1%
 * 
 * Base Inventory: 10 slots
 * Max with all legendary gear: 10 + (10×5) = 60 slots
 */


// ============================================
// GEAR TYPE STAT TENDENCIES
// ============================================

/**
 * HELMET:
 * - Primary: Trick Score, Combo Multiplier, Blood Amount
 * - Theme: "Head" protection, thinking/scoring bonuses
 * 
 * TORSO (Jacket):
 * - Primary: Speed, Acceleration, Grind Speed
 * - Theme: Core strength, momentum
 * 
 * LEGS (Pants):
 * - Primary: Jump, Kickflip Speed, Air Control
 * - Theme: Lower body power, aerial abilities
 * 
 * SHOES (Sneakers):
 * - Primary: Turn Speed, Air Control, Trick Score
 * - Theme: Foot control, precision movement
 * 
 * BOARD (Deck):
 * - Primary: Speed, Jump, Grind Speed
 * - Theme: Equipment power, all-around performance
 */


// ============================================
// INTEGRATION CHECKLIST
// ============================================

/**
 * ✅ Initialize gear module in level
 * ✅ Add gear.update() to game loop
 * ✅ Hook loot drops into enemy deaths
 * ✅ Use engine.state.gearStats in gameplay calculations
 * ✅ Create UI for inventory/equipment
 * ✅ Implement visual gear loading (helmets work, others TODO)
 * ✅ Add save/load calls on game start/exit
 * ✅ Test loot generation and crafting
 */
