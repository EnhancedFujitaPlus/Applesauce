/**
 * VERLET CLOTH PHYSICS IMPLEMENTATION GUIDE
 * How to add realistic cloth simulation to jackets in APPLESAUCE
 */

// ============================================
// WHAT IS VERLET INTEGRATION?
// ============================================

/**
 * Verlet integration is a numerical method for simulating physics
 * that's perfect for cloth because it:
 * - Conserves energy naturally
 * - Is simple to implement
 * - Handles constraints well (like keeping fabric together)
 * - Runs fast enough for real-time games
 * 
 * Basic concept:
 * 1. Cloth is a grid of connected points (vertices)
 * 2. Each point has position, previous position, velocity
 * 3. Points are connected by distance constraints
 * 4. Each frame: apply forces → solve constraints → update positions
 */

// ============================================
// PHASE 1: BASIC CLOTH GRID
// ============================================

class ClothPoint {
    constructor(x, y, z, pinned = false) {
        this.position = new THREE.Vector3(x, y, z);
        this.previousPosition = new THREE.Vector3(x, y, z);
        this.acceleration = new THREE.Vector3(0, 0, 0);
        this.pinned = pinned; // Pinned points don't move (shoulders, collar)
        this.mass = 1.0;
    }

    update(deltaTime, damping = 0.99) {
        if (this.pinned) return;

        // Verlet integration
        const velocity = this.position.clone()
            .sub(this.previousPosition)
            .multiplyScalar(damping);

        this.previousPosition.copy(this.position);

        this.position
            .add(velocity)
            .add(this.acceleration.clone().multiplyScalar(deltaTime * deltaTime));

        // Reset acceleration
        this.acceleration.set(0, 0, 0);
    }

    applyForce(force) {
        if (this.pinned) return;
        this.acceleration.add(force.clone().divideScalar(this.mass));
    }
}

class ClothConstraint {
    constructor(pointA, pointB, restLength = null) {
        this.pointA = pointA;
        this.pointB = pointB;
        this.restLength = restLength || pointA.position.distanceTo(pointB.position);
        this.stiffness = 1.0; // 0.0 = no constraint, 1.0 = rigid
    }

    solve() {
        if (this.pointA.pinned && this.pointB.pinned) return;

        const delta = this.pointB.position.clone().sub(this.pointA.position);
        const currentLength = delta.length();
        const diff = (currentLength - this.restLength) / currentLength;

        const offset = delta.multiplyScalar(diff * 0.5 * this.stiffness);

        if (!this.pointA.pinned) {
            this.pointA.position.add(offset);
        }
        if (!this.pointB.pinned) {
            this.pointB.position.sub(offset);
        }
    }
}

class ClothSimulation {
    constructor(width, height, segments) {
        this.width = width;
        this.height = height;
        this.segments = segments;
        this.points = [];
        this.constraints = [];
        
        this.gravity = new THREE.Vector3(0, -9.8, 0);
        this.wind = new THREE.Vector3(0, 0, 0);
        this.damping = 0.99;
        
        this.initializeGrid();
        this.createConstraints();
    }

    initializeGrid() {
        const segmentWidth = this.width / this.segments;
        const segmentHeight = this.height / this.segments;

        for (let y = 0; y <= this.segments; y++) {
            for (let x = 0; x <= this.segments; x++) {
                const posX = x * segmentWidth - this.width / 2;
                const posY = -y * segmentHeight;
                const posZ = 0;

                // Pin top row (shoulders/collar)
                const pinned = (y === 0);

                const point = new ClothPoint(posX, posY, posZ, pinned);
                this.points.push(point);
            }
        }
    }

    createConstraints() {
        const w = this.segments + 1;

        // Structural constraints (horizontal and vertical)
        for (let y = 0; y <= this.segments; y++) {
            for (let x = 0; x <= this.segments; x++) {
                const index = y * w + x;

                // Horizontal
                if (x < this.segments) {
                    this.constraints.push(
                        new ClothConstraint(this.points[index], this.points[index + 1])
                    );
                }

                // Vertical
                if (y < this.segments) {
                    this.constraints.push(
                        new ClothConstraint(this.points[index], this.points[index + w])
                    );
                }
            }
        }

        // Shear constraints (diagonals)
        for (let y = 0; y < this.segments; y++) {
            for (let x = 0; x < this.segments; x++) {
                const index = y * w + x;

                this.constraints.push(
                    new ClothConstraint(this.points[index], this.points[index + w + 1])
                );
                this.constraints.push(
                    new ClothConstraint(this.points[index + 1], this.points[index + w])
                );
            }
        }

        // Bend constraints (skip one)
        for (let y = 0; y <= this.segments; y++) {
            for (let x = 0; x <= this.segments; x++) {
                const index = y * w + x;

                if (x < this.segments - 1) {
                    this.constraints.push(
                        new ClothConstraint(this.points[index], this.points[index + 2])
                    );
                }

                if (y < this.segments - 1) {
                    this.constraints.push(
                        new ClothConstraint(this.points[index], this.points[index + w * 2])
                    );
                }
            }
        }
    }

    update(deltaTime = 0.016) {
        // Apply forces to all points
        this.points.forEach(point => {
            point.applyForce(this.gravity.clone().multiplyScalar(0.1));
            point.applyForce(this.wind);
        });

        // Update positions
        this.points.forEach(point => {
            point.update(deltaTime, this.damping);
        });

        // Solve constraints (multiple iterations for stability)
        const iterations = 3;
        for (let i = 0; i < iterations; i++) {
            this.constraints.forEach(constraint => {
                constraint.solve();
            });
        }
    }

    getPositions() {
        return this.points.map(p => p.position);
    }
}


// ============================================
// PHASE 2: INTEGRATING WITH THREE.JS
// ============================================

class ClothMesh {
    constructor(simulation, material) {
        this.simulation = simulation;
        this.geometry = this.createGeometry();
        this.material = material;
        this.mesh = new THREE.Mesh(this.geometry, this.material);
        this.mesh.castShadow = true;
        this.mesh.receiveShadow = true;
    }

    createGeometry() {
        const segments = this.simulation.segments;
        const geometry = new THREE.PlaneGeometry(
            this.simulation.width,
            this.simulation.height,
            segments,
            segments
        );

        // Enable dynamic updates
        geometry.dynamic = true;

        return geometry;
    }

    update() {
        const positions = this.simulation.getPositions();
        const vertices = this.geometry.attributes.position.array;

        for (let i = 0; i < positions.length; i++) {
            vertices[i * 3] = positions[i].x;
            vertices[i * 3 + 1] = positions[i].y;
            vertices[i * 3 + 2] = positions[i].z;
        }

        this.geometry.attributes.position.needsUpdate = true;
        this.geometry.computeVertexNormals();
    }

    getMesh() {
        return this.mesh;
    }
}


// ============================================
// PHASE 3: JACKET-SPECIFIC CLOTH SETUP
// ============================================

class JacketClothPhysics {
    constructor(jacketGroup, config = {}) {
        this.jacketGroup = jacketGroup;
        
        // Config
        this.enabled = config.enabled || false;
        this.stiffness = config.stiffness || 0.8;
        this.windStrength = config.windStrength || 0;
        
        // Cloth simulations for different jacket parts
        this.backCloth = null;
        this.sleeveClothLeft = null;
        this.sleeveClothRight = null;
        
        if (this.enabled) {
            this.initializeCloth();
        }
    }

    initializeCloth() {
        // Create cloth for jacket back
        this.backCloth = new ClothSimulation(1.8, 2.0, 16);
        this.backCloth.constraints.forEach(c => c.stiffness = this.stiffness);
        
        const backMaterial = new THREE.MeshStandardMaterial({
            color: 0x1a1a1a,
            side: THREE.DoubleSide,
            roughness: 0.9
        });
        
        this.backClothMesh = new ClothMesh(this.backCloth, backMaterial);
        this.backClothMesh.getMesh().position.z = -0.3;
        
        this.jacketGroup.add(this.backClothMesh.getMesh());
    }

    setWind(direction, strength) {
        if (!this.enabled) return;
        
        this.windStrength = strength;
        const wind = direction.clone().multiplyScalar(strength);
        
        if (this.backCloth) {
            this.backCloth.wind.copy(wind);
        }
    }

    update() {
        if (!this.enabled) return;
        
        // Update cloth simulation
        if (this.backCloth) {
            this.backCloth.update();
            this.backClothMesh.update();
        }
    }

    setStiffness(value) {
        this.stiffness = value;
        
        if (this.backCloth) {
            this.backCloth.constraints.forEach(c => c.stiffness = value);
        }
    }
}


// ============================================
// PHASE 4: INTEGRATION WITH JACKET LOADER
// ============================================

/**
 * Add to JacketLoader class:
 */

/*
class JacketLoader {
    constructor(scene, playerObject) {
        // ... existing code ...
        
        this.clothPhysics = null;
    }

    buildJacket(data) {
        // ... existing jacket building code ...

        // Initialize cloth physics if enabled
        if (data.physics && data.physics.simulation !== 'none') {
            this.clothPhysics = new JacketClothPhysics(this.jacketGroup, {
                enabled: true,
                stiffness: data.physics.stiffness / 100,
                windStrength: data.physics.wind / 100
            });
        }
    }

    update() {
        // Update cloth physics
        if (this.clothPhysics && this.clothPhysics.enabled) {
            this.clothPhysics.update();
        }

        // Optional: Make wind react to player movement
        if (this.clothPhysics && this.playerVelocity) {
            const windDir = this.playerVelocity.clone().normalize();
            const windStrength = this.playerVelocity.length() * 0.5;
            this.clothPhysics.setWind(windDir, windStrength);
        }
    }
}
*/


// ============================================
// PHASE 5: COLLISION DETECTION (ADVANCED)
// ============================================

class SphereCollider {
    constructor(center, radius) {
        this.center = center; // THREE.Vector3
        this.radius = radius;
    }

    checkPoint(point) {
        if (point.pinned) return;

        const distance = point.position.distanceTo(this.center);
        
        if (distance < this.radius) {
            // Push point out of sphere
            const direction = point.position.clone()
                .sub(this.center)
                .normalize();
            
            point.position.copy(
                this.center.clone().add(direction.multiplyScalar(this.radius))
            );
        }
    }
}

// Add to ClothSimulation class:
/*
class ClothSimulation {
    constructor(width, height, segments) {
        // ... existing code ...
        
        this.colliders = [];
    }

    addCollider(collider) {
        this.colliders.push(collider);
    }

    update(deltaTime = 0.016) {
        // ... existing force/constraint code ...

        // Check collisions
        this.points.forEach(point => {
            this.colliders.forEach(collider => {
                collider.checkPoint(point);
            });
        });
    }
}
*/

// Example: Add player body as collider
/*
clothSim.addCollider(new SphereCollider(
    new THREE.Vector3(0, 1, 0), // Player torso center
    0.5 // Torso radius
));
*/


// ============================================
// PHASE 6: PERFORMANCE OPTIMIZATION
// ============================================

/**
 * Tips for keeping cloth physics fast:
 * 
 * 1. Lower segment count for distant players
 * 2. Use LOD (Level of Detail) - disable physics when far from camera
 * 3. Limit constraint iterations (3 is usually enough)
 * 4. Use object pooling for cloth points
 * 5. Only simulate cloth on main player, use baked animations for NPCs
 * 6. Skip frames - update physics every other frame
 */

class OptimizedClothPhysics extends JacketClothPhysics {
    constructor(jacketGroup, config = {}) {
        super(jacketGroup, config);
        
        this.frameSkip = config.frameSkip || 0;
        this.frameCounter = 0;
        this.distanceThreshold = config.distanceThreshold || 50;
        this.camera = config.camera;
    }

    update() {
        if (!this.enabled) return;

        // Skip frames
        this.frameCounter++;
        if (this.frameCounter < this.frameSkip) return;
        this.frameCounter = 0;

        // Check distance from camera
        if (this.camera) {
            const distance = this.jacketGroup.position.distanceTo(this.camera.position);
            if (distance > this.distanceThreshold) {
                return; // Too far, skip physics
            }
        }

        // Run physics
        super.update();
    }
}


// ============================================
// USAGE EXAMPLE IN GAME
// ============================================

/*
// In your level initialization:
const engine = new ApplesauceCore(config);

// Create player
engine.player = createPlayer();

// Load jacket with cloth physics
engine.jacketLoader = new JacketLoader(engine.scene, engine.player);
engine.jacketLoader.loadJacket();

// Main game loop
function animate() {
    requestAnimationFrame(animate);
    
    // Update jacket cloth physics
    if (engine.jacketLoader) {
        engine.jacketLoader.update();
    }
    
    engine.renderer.render(engine.scene, engine.camera);
}

animate();
*/


// ============================================
// SIMPLIFIED VERSION (START HERE)
// ============================================

/**
 * If full Verlet is too complex, start with simple animated cloth:
 */

class SimpleClothAnimation {
    constructor(mesh, config = {}) {
        this.mesh = mesh;
        this.windStrength = config.windStrength || 0;
        this.time = 0;
    }

    update(deltaTime = 0.016) {
        this.time += deltaTime;

        const vertices = this.mesh.geometry.attributes.position.array;
        const originalVertices = this.mesh.userData.originalVertices;

        if (!originalVertices) {
            // Store original positions on first run
            this.mesh.userData.originalVertices = vertices.slice();
            return;
        }

        // Apply sine wave deformation
        for (let i = 0; i < vertices.length; i += 3) {
            const x = originalVertices[i];
            const y = originalVertices[i + 1];
            const z = originalVertices[i + 2];

            // Wave based on Y position
            const wave = Math.sin(this.time * 2 + y * 2) * this.windStrength * 0.1;

            vertices[i] = x + wave;
            vertices[i + 1] = y;
            vertices[i + 2] = z + wave * 0.5;
        }

        this.mesh.geometry.attributes.position.needsUpdate = true;
        this.mesh.geometry.computeVertexNormals();
    }

    setWindStrength(strength) {
        this.windStrength = strength;
    }
}

// Use in JacketLoader:
/*
this.simpleCloth = new SimpleClothAnimation(backMesh, {
    windStrength: data.physics.wind / 100
});

// In update():
if (this.simpleCloth) {
    this.simpleCloth.update();
}
*/


// ============================================
// NEXT STEPS
// ============================================

/**
 * PHASE 1: ✅ Start with SimpleClothAnimation
 * - Easy to implement
 * - Works immediately
 * - Good for testing
 * 
 * PHASE 2: Implement basic ClothSimulation
 * - More realistic
 * - Still performant
 * - No collision yet
 * 
 * PHASE 3: Add collision detection
 * - Prevents clipping through player
 * - More complex but worth it
 * 
 * PHASE 4: Optimize for multiplayer/NPCs
 * - LOD systems
 * - Frame skipping
 * - Baked animations for distant objects
 */
