// VolcanoSystem.js
class VolcanoSystem {
    constructor(scene, config, weatherSystem) {
        this.scene = scene;
        this.weatherSystem = weatherSystem;
        
        // Config
        this.position = config.position || new THREE.Vector3(0, 0, 0);
        this.height = config.height || 40;
        this.radius = config.baseRadius || 30;
        this.eruptionInterval = config.eruptionInterval || 300; // frames
        this.eruptionDuration = config.eruptionDuration || 180;
        this.projectileCount = config.projectileCount || 15;
        
        // State
        this.timer = 0;
        this.isErupting = false;
        this.eruptionTimer = 0;
        this.lavaFlows = [];
        
        this.createVolcano();
    }
    
    createVolcano() {
        // Main volcano cone
        const geometry = new THREE.ConeGeometry(this.radius, this.height, 16);
        const material = new THREE.MeshLambertMaterial({ 
            color: 0x4a4a4a 
        });
        this.volcano = new THREE.Mesh(geometry, material);
        this.volcano.position.copy(this.position);
        this.volcano.position.y = this.height / 2;
        this.scene.add(this.volcano);
        
        // Crater at top (glowing)
        const craterGeo = new THREE.CylinderGeometry(5, 3, 2, 16);
        const craterMat = new THREE.MeshBasicMaterial({ 
            color: 0xFF4500,
            emissive: 0xFF4500
        });
        this.crater = new THREE.Mesh(craterGeo, craterMat);
        this.crater.position.copy(this.position);
        this.crater.position.y = this.height;
        this.scene.add(this.crater);
        
        // Lava pool at base (optional - adds danger zone)
        this.createLavaPool();
    }
    
    createLavaPool() {
        const poolGeo = new THREE.CircleGeometry(this.radius + 10, 32);
        const poolMat = new THREE.MeshBasicMaterial({ 
            color: 0xFF4500,
            emissive: 0xFF6600,
            side: THREE.DoubleSide
        });
        this.lavaPool = new THREE.Mesh(poolGeo, poolMat);
        this.lavaPool.rotation.x = -Math.PI / 2;
        this.lavaPool.position.copy(this.position);
        this.lavaPool.position.y = 0.1;
        this.scene.add(this.lavaPool);
        
        // Pulsing glow effect
        this.poolBrightness = 0;
    }
    
    update(playerPosition, delta) {
        this.timer++;
        
        // Pulsing lava pool
        this.poolBrightness += 0.05;
        const brightness = 0.8 + Math.sin(this.poolBrightness) * 0.2;
        this.crater.material.emissiveIntensity = brightness;
        
        // Check if player is in lava pool
        const distToPlayer = new THREE.Vector2(
            playerPosition.x - this.position.x,
            playerPosition.z - this.position.z
        ).length();
        
        if (distToPlayer < this.radius + 10) {
            this.weatherSystem.eventBus.emit('playerInLava', {
                damage: 5,
                position: playerPosition
            });
        }
        
        // Eruption cycle
        if (!this.isErupting && this.timer >= this.eruptionInterval) {
            this.startEruption();
        }
        
        if (this.isErupting) {
            this.updateEruption(playerPosition);
        }
        
        // Update lava flows
        this.updateLavaFlows();
    }
    
    startEruption() {
        this.isErupting = true;
        this.eruptionTimer = this.eruptionDuration;
        this.timer = 0;
        
        // Visual feedback - crater brightens
        this.crater.material.emissive.setHex(0xFFFF00);
        
        // Rumble effect (could emit to camera shake)
        this.weatherSystem.eventBus.emit('volcanoErupting', {
            position: this.position,
            intensity: 1.0
        });
    }
    
    updateEruption(playerPosition) {
        this.eruptionTimer--;
        
        // Launch projectiles randomly during eruption
        if (this.eruptionTimer % 10 === 0) {
            this.launchLavaRock(playerPosition);
        }
        
        // Create lava flow occasionally
        if (this.eruptionTimer % 60 === 0) {
            this.createLavaFlow();
        }
        
        if (this.eruptionTimer <= 0) {
            this.stopEruption();
        }
    }
    
    launchLavaRock(playerPosition) {
        // Create physics-based projectile
        const craterPos = new THREE.Vector3(
            this.position.x,
            this.height,
            this.position.z
        );
        
        // Aim toward player with some randomness
        const toPlayer = playerPosition.clone().sub(craterPos).normalize();
        const randomOffset = new THREE.Vector3(
            (Math.random() - 0.5) * 0.5,
            0,
            (Math.random() - 0.5) * 0.5
        );
        const direction = toPlayer.add(randomOffset).normalize();
        
        // Launch velocity (upward arc)
        const launchSpeed = 0.8 + Math.random() * 0.4;
        const velocity = new THREE.Vector3(
            direction.x * launchSpeed,
            0.6 + Math.random() * 0.3, // Upward
            direction.z * launchSpeed
        );
        
        const lavaRock = new LavaProjectile({
            position: craterPos.clone(),
            velocity: velocity,
            size: 0.8 + Math.random() * 0.6,
            damage: 30
        });
        
        this.weatherSystem.hazards.push(lavaRock);
    }
    
    createLavaFlow() {
        // Flowing lava down the side
        const angle = Math.random() * Math.PI * 2;
        const startPos = new THREE.Vector3(
            this.position.x + Math.cos(angle) * 10,
            this.height * 0.7,
            this.position.z + Math.sin(angle) * 10
        );
        
        const flow = new LavaFlow(this.scene, startPos, angle, this.radius);
        this.lavaFlows.push(flow);
    }
    
    updateLavaFlows() {
        for (let i = this.lavaFlows.length - 1; i >= 0; i--) {
            const flow = this.lavaFlows[i];
            if (!flow.update()) {
                flow.remove(this.scene);
                this.lavaFlows.splice(i, 1);
            }
        }
    }
    
    stopEruption() {
        this.isErupting = false;
        this.crater.material.emissive.setHex(0xFF4500);
    }
}