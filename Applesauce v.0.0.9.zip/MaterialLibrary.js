// MaterialLibrary.js
class MaterialLibrary {
    constructor() {
        this.materials = {};
        this.initMaterials();
    }
    
    initMaterials() {
        this.materials.concrete = new THREE.MeshLambertMaterial({ 
            color: 0x808080 
        });
        this.materials.metal = new THREE.MeshLambertMaterial({ 
            color: 0xC0C0C0 
        });
        this.materials.blood = new THREE.MeshBasicMaterial({ 
            color: 0x8B0000,
            transparent: true,
            opacity: 0.8
        });
        // ...
    }
    
    get(name) {
        return this.materials[name] || this.materials.concrete;
    }
}