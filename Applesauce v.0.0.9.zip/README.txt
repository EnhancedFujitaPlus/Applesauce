Hello! This is v0.0.9! What you got here is a skateboarding game! 

Thanks for checking it out!

index.html is the main menu. This is attempt 1 at running the game offline.

If it doesn't work you might have to run the level htmls directly

if it doesnt work it might not be done yet
----
--------
------------
---------------
----------------------------------------{-------+++_-+_
-----------------------------------------{-------+---+

The game is about getting people to wear a helmet and what happens if you don't, as well as what happens if you DO wear a helmet (you can still get hurt).

Fly through levels with quests and dialogue systems. edit your helmet and other gear. This is where were at developmentally lol. Putting loot systems onto enemies
and then having them drop gear and then you pick up the gear and then it shows up physically onto your character. I just learned how to put the helmet on from the
main menu.

Enjoy!

Applesauce is developed by 2 people with 0 coding experience. It's been assisted by AI to help learn the coding, but all music, 
graphics, story, narrative, dialogue, jokes, creation, hate, direction, elements of psychosis, technical scramble, and non-verbular sequeters,
and blocks of cream cheese (the code) will be/has already been decrafted and recrafted manually.

all to be anti-robot by Version 1.0.0. 

One of the exceptions to this rule will be the Mysterious Man figure that sometimes appears when creating a level.

Alright now to get the .js levels working
