/**
 * APPLESAUCE Dialogue Module
 * NPC system and letter-by-letter dialogue display
 */

class ApplesauceDialogue {
    constructor(engine) {
        this.engine = engine;
        this.isActive = false;
        this.isTyping = false;
        this.currentDialogue = [];
        this.currentIndex = 0;
        this.currentText = "";
        this.typingSpeed = 30; // milliseconds per character
        this.typingTimer = null;
        this.npcs = [];
        this.nearNPC = null;
        
        // Get DOM elements
        this.bubble = document.getElementById('speechBubble');
        this.speakerName = document.getElementById('speakerName');
        this.speechText = document.getElementById('speechText');
        this.interactPrompt = document.getElementById('interactPrompt');
        
        // Setup F key listener
        this._setupControls();
        
        console.log('💬 Dialogue module loaded');
    }
    
    _setupControls() {
        document.addEventListener('keydown', (e) => {
            if (e.key.toLowerCase() === 'f') {
                if (this.nearNPC && !this.isActive) {
                    // Start dialogue with nearby NPC
                    this.start(this.nearNPC.dialogue);
                } else if (this.isActive) {
                    // Advance dialogue
                    this.advance();
                }
            }
        });
    }
    
    // ===================================
    // DIALOGUE CONTROL
    // ===================================
    start(dialogue) {
        this.isActive = true;
        this.currentDialogue = dialogue;
        this.currentIndex = 0;
        this.showLine(0);
        this.bubble.classList.add('active');
    }
    
    showLine(index) {
        if (index >= this.currentDialogue.length) {
            this.end();
            return;
        }
        
        const line = this.currentDialogue[index];
        this.speakerName.textContent = line.speaker;
        this.speechText.textContent = "";
        this.currentText = "";
        
        this.isTyping = true;
        this.typeText(line.text, 0);
    }
    
    typeText(fullText, charIndex) {
        if (charIndex < fullText.length) {
            this.currentText += fullText[charIndex];
            this.speechText.textContent = this.currentText;
            
            this.typingTimer = setTimeout(() => {
                this.typeText(fullText, charIndex + 1);
            }, this.typingSpeed);
        } else {
            this.isTyping = false;
        }
    }
    
    advance() {
        if (this.isTyping) {
            // Skip typing animation
            clearTimeout(this.typingTimer);
            this.speechText.textContent = this.currentDialogue[this.currentIndex].text;
            this.currentText = this.currentDialogue[this.currentIndex].text;
            this.isTyping = false;
        } else {
            // Move to next line
            this.currentIndex++;
            this.showLine(this.currentIndex);
        }
    }
    
    end() {
        this.isActive = false;
        this.isTyping = false;
        this.currentDialogue = [];
        this.currentIndex = 0;
        this.bubble.classList.remove('active');
        clearTimeout(this.typingTimer);
    }
    
    // ===================================
    // NPC MANAGEMENT
    // ===================================
    createNPC(config) {
        const npc = new NPC(config, this.engine);
        this.npcs.push(npc);
        return npc;
    }
    
    update(engine) {
        // Check for nearby NPCs
        this.nearNPC = null;
        
        if (!engine.player) return;
        
        for (let npc of this.npcs) {
            const distance = npc.mesh.position.distanceTo(engine.player.position);
            
            if (distance < npc.interactRadius) {
                this.nearNPC = npc;
                break;
            }
        }
        
        // Show/hide interact prompt
        if (this.interactPrompt) {
            if (this.nearNPC && !this.isActive) {
                this.interactPrompt.style.display = 'block';
                this.interactPrompt.textContent = `Press F to talk to ${this.nearNPC.name}`;
            } else {
                this.interactPrompt.style.display = 'none';
            }
        }
    }
}

// ===================================
// NPC CLASS
// ===================================
class NPC {
    constructor(config, engine) {
        this.name = config.name || "NPC";
        this.dialogue = config.dialogue || [];
        this.position = config.position || { x: 0, y: 0, z: 0 };
        this.color = config.color || 0x00FF00;
        this.interactRadius = config.interactRadius || 5;
        this.engine = engine;
        
        this.mesh = this.createMesh();
        this.mesh.position.set(this.position.x, this.position.y, this.position.z);
        engine.scene.add(this.mesh);
    }
    
    createMesh() {
        const group = new THREE.Group();
        
        // Body (using cylinder since CapsuleGeometry doesn't exist in r128)
        const bodyGeo = new THREE.CylinderGeometry(0.3, 0.3, 1.2, 8);
        const bodyMat = new THREE.MeshLambertMaterial({ color: this.color });
        const body = new THREE.Mesh(bodyGeo, bodyMat);
        body.position.y = 0.9;
        body.castShadow = true;
        group.add(body);
        
        // Head
        const headGeo = new THREE.SphereGeometry(0.3, 16, 16);
        const headMat = new THREE.MeshLambertMaterial({ color: 0xFFDBAC });
        const head = new THREE.Mesh(headGeo, headMat);
        head.position.y = 1.8;
        head.castShadow = true;
        group.add(head);
        
        return group;
    }
    
    canInteract(playerX, playerZ) {
        const dx = playerX - this.position.x;
        const dz = playerZ - this.position.z;
        return Math.sqrt(dx * dx + dz * dz) < this.interactRadius;
    }
    
    remove() {
        this.engine.scene.remove(this.mesh);
    }
}
