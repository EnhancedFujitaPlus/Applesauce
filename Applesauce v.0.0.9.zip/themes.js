const THEMES = {
    urban: {
        ground: 0x2d2d2d,
        grass: 0x1a4d1a,
        sky: 0x87CEEB,
        accent: 0xFF1493
    },
    desert: {
        ground: 0xD2B48C,
        grass: 0x9C7C38,
        sky: 0xFF6B35,
        accent: 0xFFD700
    }
};